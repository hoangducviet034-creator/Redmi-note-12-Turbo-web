import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import './style.css';

gsap.registerPlugin(ScrollTrigger);

const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const isSmallScreen = window.matchMedia('(max-width: 800px)').matches;
const root = document.documentElement;
const canvas = document.querySelector('#phone-canvas');
const caption = document.querySelector('#stage-caption-text');
const toast = document.querySelector('#toast');
const loader = document.querySelector('#loader');
const loaderProgress = document.querySelector('#loader-progress');

const colorways = {
  black: { name: 'CARBON BLACK', body: '#151923', back: '#0b0f18', frame: '#363e4b', rimA: '#00c2ff', rimB: '#7a5cff', particle: '#7e94ff' },
  white: { name: 'ICE FEATHER WHITE', body: '#bfcddd', back: '#dce6f2', frame: '#e1eaf5', rimA: '#eaf2ff', rimB: '#8fcfff', particle: '#eaf2ff' },
  blue: { name: 'XINGHAI BLUE', body: '#0a579d', back: '#064078', frame: '#8cb7d5', rimA: '#00c2ff', rimB: '#7a5cff', particle: '#8aabff' },
};

const scenePalettes = {
  hero: { a: '#00c2ff', b: '#7a5cff', accent: '#00c2ff', caption: 'XINGHAI BLUE / 3D STUDIO' },
  design: { a: '#8bdfff', b: '#5b86c7', accent: '#00c2ff', caption: 'FORM / 7.9 MM THIN' },
  display: { a: '#00c2ff', b: '#eaf2ff', accent: '#70dfff', caption: 'OLED / 120 HZ DISPLAY' },
  performance: { a: '#00c2ff', b: '#00f0ff', accent: '#00c2ff', caption: '4 NM / SNAPDRAGON 7+ GEN 2' },
  camera: { a: '#7a5cff', b: '#b14cff', accent: '#b14cff', caption: '64 MP OIS / CAMERA SYSTEM' },
  battery: { a: '#7dffbd', b: '#00c2ff', accent: '#7dffbd', caption: '5,000 MAH / 67 W CHARGE' },
  colors: { a: '#00c2ff', b: '#b14cff', accent: '#00c2ff', caption: 'THE COLOR COLLECTION' },
  specs: { a: '#00c2ff', b: '#7a5cff', accent: '#00c2ff', caption: 'ENGINEERED IN EVERY DETAIL' },
  final: { a: '#00c2ff', b: '#b14cff', accent: '#7a5cff', caption: 'REDMI NOTE 12 TURBO / CONCEPT' },
};

let renderer;
let composer;
let scene;
let camera;
let phoneGroup;
let phoneBodyMaterial;
let backGlassMaterial;
let frameMaterial;
let keyLight;
let rimLeft;
let rimRight;
let underLight;
let backLight;
let stars;
let starsMaterial;
let targetYaw = 0.24;
let userYaw = 0;
let autoYaw = 0;
let targetTiltX = -0.04;
let targetTiltZ = 0;
let currentScene = 'hero';
let currentColor = 'blue';
let lastInteraction = performance.now();
let lastFrame = performance.now();
let pointerX = 0;
let pointerY = 0;
let toastTimer = null;
let frameCount = 0;
let loaded = false;
let pinchStart = null;
const activePointers = new Map();
const initialModelScale = isSmallScreen ? 0.88 : 1.0;

// Vẽ một panel chữ nhật bo góc để dùng cho thân máy, màn hình và đảo camera.
function roundedShape(width, height, radius) {
  const x = -width / 2;
  const y = -height / 2;
  const shape = new THREE.Shape();
  shape.moveTo(x + radius, y);
  shape.lineTo(x + width - radius, y);
  shape.quadraticCurveTo(x + width, y, x + width, y + radius);
  shape.lineTo(x + width, y + height - radius);
  shape.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  shape.lineTo(x + radius, y + height);
  shape.quadraticCurveTo(x, y + height, x, y + height - radius);
  shape.lineTo(x, y + radius);
  shape.quadraticCurveTo(x, y, x + radius, y);
  return shape;
}

function createRoundedPanel(width, height, radius, material, z, x = 0, y = 0) {
  const geometry = new THREE.ShapeGeometry(roundedShape(width, height, radius), 10);
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(x, y, z);
  mesh.renderOrder = 2;
  return mesh;
}

function makeDisplayTexture() {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 1024;
  const ctx = c.getContext('2d');
  const bg = ctx.createLinearGradient(0, 0, 512, 1024);
  bg.addColorStop(0, '#06172f');
  bg.addColorStop(.38, '#06101f');
  bg.addColorStop(.72, '#100e31');
  bg.addColorStop(1, '#020711');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, c.width, c.height);

  const glows = [
    { x: 410, y: 250, r: 270, color: '0,194,255', alpha: .72 },
    { x: 80, y: 540, r: 310, color: '122,92,255', alpha: .64 },
    { x: 380, y: 800, r: 280, color: '177,76,255', alpha: .42 },
  ];
  glows.forEach(g => {
    const radial = ctx.createRadialGradient(g.x, g.y, 2, g.x, g.y, g.r);
    radial.addColorStop(0, `rgba(${g.color},${g.alpha})`);
    radial.addColorStop(.42, `rgba(${g.color},${g.alpha * .23})`);
    radial.addColorStop(1, `rgba(${g.color},0)`);
    ctx.fillStyle = radial;
    ctx.fillRect(0, 0, c.width, c.height);
  });

  // Các đường cong trừu tượng tạo cảm giác màn hình phát sáng, không dùng ảnh ngoài.
  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  for (let i = 0; i < 9; i++) {
    ctx.beginPath();
    ctx.moveTo(-70, 280 + i * 46);
    ctx.bezierCurveTo(140, 170 + i * 17, 250, 520 + i * 30, 590, 350 + i * 53);
    ctx.lineWidth = i % 3 === 0 ? 3 : 1.1;
    ctx.strokeStyle = i % 2 === 0 ? 'rgba(66,210,255,.22)' : 'rgba(179,118,255,.18)';
    ctx.shadowColor = i % 2 === 0 ? '#00c2ff' : '#7a5cff';
    ctx.shadowBlur = i % 3 === 0 ? 18 : 8;
    ctx.stroke();
  }
  ctx.restore();

  for (let i = 0; i < 95; i++) {
    const x = Math.random() * c.width;
    const y = Math.random() * c.height;
    const r = Math.random() * 1.5 + .2;
    ctx.beginPath();
    ctx.fillStyle = `rgba(220,243,255,${Math.random() * .42 + .08})`;
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  const texture = new THREE.CanvasTexture(c);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  return texture;
}

function makePhone() {
  phoneGroup = new THREE.Group();
  phoneGroup.scale.setScalar(initialModelScale);
  scene.add(phoneGroup);

  const width = 1.72;
  const height = 3.68;
  const depth = .14;
  const bodyShape = roundedShape(width, height, .18);
  const bodyGeometry = new THREE.ExtrudeGeometry(bodyShape, {
    depth,
    bevelEnabled: true,
    bevelSegments: 3,
    steps: 1,
    bevelSize: .018,
    bevelThickness: .02,
    curveSegments: 10,
  });
  bodyGeometry.translate(0, 0, -depth / 2);
  phoneBodyMaterial = new THREE.MeshPhysicalMaterial({ color: colorways.blue.body, metalness: .46, roughness: .24, clearcoat: .95, clearcoatRoughness: .14 });
  const body = new THREE.Mesh(bodyGeometry, phoneBodyMaterial);
  body.castShadow = true;
  body.receiveShadow = true;
  phoneGroup.add(body);

  frameMaterial = new THREE.MeshPhysicalMaterial({ color: colorways.blue.frame, metalness: .82, roughness: .2, clearcoat: .8, clearcoatRoughness: .12 });
  // Dải viền kim loại mảnh tạo highlight quanh mặt trước.
  const frontRim = createRoundedPanel(1.685, 3.64, .17, frameMaterial, .079);
  const screenMaskMaterial = new THREE.MeshPhysicalMaterial({ color: '#030710', metalness: .12, roughness: .18, clearcoat: 1, clearcoatRoughness: .05 });
  const screenMask = createRoundedPanel(1.63, 3.57, .145, screenMaskMaterial, .091);
  const displayTexture = makeDisplayTexture();
  const screenMaterial = new THREE.MeshPhysicalMaterial({
    map: displayTexture,
    emissiveMap: displayTexture,
    emissive: new THREE.Color('#b4eaff'),
    emissiveIntensity: .25,
    metalness: .08,
    roughness: .2,
    clearcoat: 1,
    clearcoatRoughness: .08,
  });
  const display = createRoundedPanel(1.59, 3.48, .13, screenMaterial, .097);
  phoneGroup.add(frontRim, screenMask, display);

  // Camera trước dạng punch-hole.
  const holeOuter = new THREE.Mesh(new THREE.CircleGeometry(.057, 40), new THREE.MeshPhysicalMaterial({ color: '#101a29', metalness: .65, roughness: .2 }));
  holeOuter.position.set(0, 1.59, .103);
  phoneGroup.add(holeOuter);
  const holeInner = new THREE.Mesh(new THREE.CircleGeometry(.037, 40), new THREE.MeshBasicMaterial({ color: '#01040a' }));
  holeInner.position.set(0, 1.59, .105);
  phoneGroup.add(holeInner);
  const tinyGlass = new THREE.Mesh(new THREE.CircleGeometry(.011, 20), new THREE.MeshBasicMaterial({ color: '#245782' }));
  tinyGlass.position.set(.01, 1.60, .107);
  phoneGroup.add(tinyGlass);

  // Mặt kính lưng và cụm camera tự dựng theo bố cục hai ống kính lớn dọc.
  backGlassMaterial = new THREE.MeshPhysicalMaterial({ color: colorways.blue.back, metalness: .24, roughness: .19, clearcoat: 1, clearcoatRoughness: .1, side: THREE.DoubleSide });
  const rearGlass = createRoundedPanel(1.66, 3.61, .16, backGlassMaterial, -.096);
  rearGlass.material.side = THREE.DoubleSide;
  phoneGroup.add(rearGlass);

  const islandMat = new THREE.MeshPhysicalMaterial({ color: '#101a2c', metalness: .5, roughness: .21, clearcoat: 1, clearcoatRoughness: .1, side: THREE.DoubleSide });
  const cameraIsland = createRoundedPanel(.79, 1.24, .105, islandMat, -.112, -.39, 1.08);
  phoneGroup.add(cameraIsland);

  const ringMaterial = new THREE.MeshPhysicalMaterial({ color: '#9ebbd6', metalness: .9, roughness: .19, clearcoat: 1, clearcoatRoughness: .07, side: THREE.DoubleSide });
  const lensGlassMaterial = new THREE.MeshPhysicalMaterial({ color: '#06182e', metalness: .35, roughness: .1, clearcoat: 1, clearcoatRoughness: .04, emissive: '#082b52', emissiveIntensity: .22, side: THREE.DoubleSide });
  const lensGlintMaterial = new THREE.MeshBasicMaterial({ color: '#73dcff', side: THREE.DoubleSide });

  function addLens(x, y, radius, glowColor) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(radius, radius * .1, 8, 36), ringMaterial);
    ring.position.set(x, y, -.124);
    phoneGroup.add(ring);
    const glass = new THREE.Mesh(new THREE.CircleGeometry(radius * .87, 36), lensGlassMaterial.clone());
    glass.position.set(x, y, -.125);
    glass.material.emissive.set(glowColor);
    phoneGroup.add(glass);
    const innerRing = new THREE.Mesh(new THREE.TorusGeometry(radius * .52, radius * .035, 6, 30), lensGlintMaterial);
    innerRing.position.set(x, y, -.127);
    innerRing.material = new THREE.MeshBasicMaterial({ color: glowColor, transparent: true, opacity: .75, side: THREE.DoubleSide });
    phoneGroup.add(innerRing);
    const reflection = new THREE.Mesh(new THREE.CircleGeometry(radius * .17, 16), new THREE.MeshBasicMaterial({ color: '#eaf7ff', transparent: true, opacity: .75, side: THREE.DoubleSide }));
    reflection.position.set(x - radius * .27, y + radius * .25, -.129);
    phoneGroup.add(reflection);
    return glass;
  }
  addLens(-.51, 1.43, .177, '#063b78');
  addLens(-.51, .94, .15, '#092c5c');
  addLens(-.16, .69, .092, '#141d4d');

  const flash = new THREE.Mesh(new THREE.CircleGeometry(.047, 28), new THREE.MeshBasicMaterial({ color: '#fff5c8' }));
  flash.position.set(-.16, 1.16, -.125);
  phoneGroup.add(flash);
  const flashRim = new THREE.Mesh(new THREE.TorusGeometry(.05, .009, 6, 24), ringMaterial);
  flashRim.position.set(-.16, 1.16, -.126);
  phoneGroup.add(flashRim);
  const cameraLabel = new THREE.Mesh(new THREE.BoxGeometry(.23, .012, .004), new THREE.MeshBasicMaterial({ color: '#7293b6', transparent: true, opacity: .45 }));
  cameraLabel.position.set(-.22, 1.48, -.115);
  phoneGroup.add(cameraLabel);

  // Nút bấm ở cạnh phẳng, có highlight nhỏ.
  const buttonMat = new THREE.MeshPhysicalMaterial({ color: '#91a9c2', metalness: .85, roughness: .22 });
  const volumeButton = new THREE.Mesh(new THREE.BoxGeometry(.035, .38, .066), buttonMat);
  volumeButton.position.set(.866, .43, .005);
  phoneGroup.add(volumeButton);
  const powerButton = new THREE.Mesh(new THREE.BoxGeometry(.035, .26, .066), buttonMat);
  powerButton.position.set(.866, -.05, .005);
  phoneGroup.add(powerButton);
  const antennaTop = new THREE.Mesh(new THREE.BoxGeometry(.012, .045, .146), new THREE.MeshBasicMaterial({ color: '#8cb7d5', transparent: true, opacity: .65 }));
  antennaTop.position.set(-.862, 1.2, 0);
  phoneGroup.add(antennaTop);
  const antennaBottom = antennaTop.clone();
  antennaBottom.position.y = -1.22;
  phoneGroup.add(antennaBottom);

  // Một vạch phản chiếu chạy trên mặt lưng.
  const backSweepMat = new THREE.MeshBasicMaterial({ color: '#73dfff', transparent: true, opacity: .17, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false });
  const sweepShape = new THREE.Shape();
  sweepShape.moveTo(-.45, -1.75); sweepShape.lineTo(-.17, -1.75); sweepShape.lineTo(.56, 1.7); sweepShape.lineTo(.3, 1.7); sweepShape.closePath();
  const sweep = new THREE.Mesh(new THREE.ShapeGeometry(sweepShape), backSweepMat);
  sweep.position.z = -.099;
  sweep.name = 'back-light-sweep';
  phoneGroup.add(sweep);

  return phoneGroup;
}

function makeStars() {
  const count = isSmallScreen ? 240 : 760;
  const positions = new Float32Array(count * 3);
  const sizes = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    positions[i * 3] = (Math.random() - .5) * 11;
    positions[i * 3 + 1] = (Math.random() - .5) * 9;
    positions[i * 3 + 2] = (Math.random() - .5) * 5 - 1;
    sizes[i] = Math.random() * .025 + .007;
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
  starsMaterial = new THREE.PointsMaterial({ color: colorways.blue.particle, size: isSmallScreen ? .025 : .032, transparent: true, opacity: .68, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
  stars = new THREE.Points(geometry, starsMaterial);
  scene.add(stars);
}

function initThree() {
  scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2('#04050a', .035);
  camera = new THREE.PerspectiveCamera(33, 1, .1, 70);
  camera.position.set(0, 0, 8.4);
  camera.lookAt(0, 0, 0);

  renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: !isSmallScreen, powerPreference: 'high-performance', stencil: false, depth: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isSmallScreen ? 1.25 : 1.65));
  const stageRect = canvas.parentElement.getBoundingClientRect();
  renderer.setSize(Math.max(1, Math.round(stageRect.width)), Math.max(1, Math.round(stageRect.height)), false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.setClearColor('#04050a', 0);

  const pmrem = new THREE.PMREMGenerator(renderer);
  const room = new RoomEnvironment();
  const env = pmrem.fromScene(room, .04);
  scene.environment = env.texture;
  room.dispose();
  pmrem.dispose();

  scene.add(new THREE.HemisphereLight('#b8dfff', '#070817', 1.05));
  keyLight = new THREE.DirectionalLight('#eaf2ff', 3.4);
  keyLight.position.set(-3.8, 5.5, 6.4);
  scene.add(keyLight);
  rimLeft = new THREE.PointLight('#00c2ff', 5.2, 13, 1.8);
  rimLeft.position.set(-3.4, .6, -2.2);
  scene.add(rimLeft);
  rimRight = new THREE.PointLight('#7a5cff', 5.4, 13, 1.7);
  rimRight.position.set(3.2, 1.2, -1.5);
  scene.add(rimRight);
  underLight = new THREE.PointLight('#1689ff', 2.1, 9, 2);
  underLight.position.set(0, -3.4, 2);
  scene.add(underLight);
  backLight = new THREE.PointLight('#b14cff', 3, 10, 1.8);
  backLight.position.set(.2, 3.7, -3.6);
  scene.add(backLight);

  makePhone();
  makeStars();

  const renderPass = new RenderPass(scene, camera);
  composer = new EffectComposer(renderer);
  composer.addPass(renderPass);
  const bloomStrength = reduceMotion ? .32 : (isSmallScreen ? .48 : .72);
  const bloomRect = canvas.parentElement.getBoundingClientRect();
  const bloom = new UnrealBloomPass(new THREE.Vector2(Math.max(1, Math.round(bloomRect.width)), Math.max(1, Math.round(bloomRect.height))), bloomStrength, .65, .22);
  composer.addPass(bloom);

  resizeThree();
  applyScenePalette(currentScene);
  tick(performance.now());
}

const sceneYaw = {
  hero: .28,
  design: 1.17,
  display: .04,
  performance: -.48,
  camera: Math.PI,
  battery: 2.5,
  colors: Math.PI - .08,
  specs: .1,
  final: .32,
};
const sceneTilt = {
  hero: -.06,
  design: .12,
  display: -.02,
  performance: -.19,
  camera: -.08,
  battery: .1,
  colors: -.04,
  specs: .02,
  final: -.04,
};

function applyScenePalette(sceneName) {
  const palette = scenePalettes[sceneName] || scenePalettes.hero;
  const chosen = colorways[currentColor];
  const accentA = sceneName === 'colors' ? chosen.rimA : palette.a;
  const accentB = sceneName === 'colors' ? chosen.rimB : palette.b;
  root.style.setProperty('--cyan', accentA);
  root.style.setProperty('--violet', accentB);
  root.style.setProperty('--magenta', sceneName === 'camera' || sceneName === 'final' ? '#b14cff' : '#9e70ff');
  caption.textContent = sceneName === 'colors' ? `${chosen.name} / COLOR STUDY` : palette.caption;
  if (rimLeft) {
    rimLeft.color.set(accentA);
    rimRight.color.set(accentB);
    underLight.color.set(sceneName === 'battery' ? '#45ffc1' : accentA);
    backLight.color.set(accentB);
    rimLeft.intensity = sceneName === 'display' ? 4.8 : 5.2;
    rimRight.intensity = sceneName === 'camera' ? 6.1 : 5.4;
    underLight.intensity = sceneName === 'battery' ? 3.2 : 2.1;
  }
  if (starsMaterial) starsMaterial.color.set(sceneName === 'colors' ? chosen.particle : accentB);
  const halo = document.querySelector('.phone-halo');
  if (halo) halo.style.background = `radial-gradient(circle, ${accentA}28, ${accentB}22 38%, transparent 70%)`;
  document.querySelectorAll('.orbit').forEach((el, index) => {
    el.style.borderColor = index === 0 ? `${accentA}42` : `${accentB}30`;
    el.style.boxShadow = `0 0 28px ${accentA}10, inset 0 0 22px ${accentB}08`;
  });
}

function setScene(name) {
  if (!scenePalettes[name] || currentScene === name) return;
  currentScene = name;
  targetYaw = sceneYaw[name] ?? .2;
  targetTiltZ = sceneTilt[name] ?? 0;
  applyScenePalette(name);
  gsap.to('.phone-stage', { opacity: name === 'specs' ? .47 : 1, duration: .8, overwrite: true });
  gsap.to('.orbit-one', { width: name === 'battery' ? '77%' : name === 'camera' ? '51%' : '58%', duration: 1.1, ease: 'power2.out', overwrite: true });
}

function resizeThree() {
  if (!renderer || !camera || !composer) return;
  // Canvas theo đúng kích thước stage; tránh bóp méo mô hình trên mobile.
  const rect = canvas.parentElement.getBoundingClientRect();
  const width = Math.max(1, Math.round(rect.width));
  const height = Math.max(1, Math.round(rect.height));
  camera.aspect = width / height;
  camera.position.z = isSmallScreen ? 8.9 : 8.4;
  camera.updateProjectionMatrix();
  renderer.setSize(width, height, false);
  composer.setSize(width, height);
}

function tick(now) {
  requestAnimationFrame(tick);
  if (!renderer || !scene || !camera || !phoneGroup) return;
  const dt = Math.min((now - lastFrame) / 1000, .05);
  lastFrame = now;
  const idleFor = now - lastInteraction;
  if (!reduceMotion && idleFor > 3000) autoYaw += dt * (isSmallScreen ? .10 : .13);
  else autoYaw = THREE.MathUtils.damp(autoYaw, 0, 2.2, dt);

  const time = now * .001;
  const yaw = targetYaw + userYaw + autoYaw;
  phoneGroup.rotation.y = THREE.MathUtils.damp(phoneGroup.rotation.y, yaw, 4.4, dt);
  const cursorTiltX = !isSmallScreen && !reduceMotion ? (pointerY - .5) * .09 : 0;
  const cursorTiltZ = !isSmallScreen && !reduceMotion ? (pointerX - .5) * -.06 : 0;
  phoneGroup.rotation.x = THREE.MathUtils.damp(phoneGroup.rotation.x, targetTiltX + cursorTiltX + Math.sin(time * .45) * (reduceMotion ? 0 : .012), 3.5, dt);
  phoneGroup.rotation.z = THREE.MathUtils.damp(phoneGroup.rotation.z, targetTiltZ + cursorTiltZ + Math.sin(time * .35) * (reduceMotion ? 0 : .008), 3.5, dt);
  phoneGroup.position.y = Math.sin(time * .7) * (reduceMotion ? 0 : .045);
  if (stars) {
    stars.rotation.y += dt * (reduceMotion ? 0 : .012);
    stars.rotation.x = Math.sin(time * .13) * .03;
    const pos = stars.geometry.attributes.position;
    for (let i = 1; i < pos.count; i++) {
      const y = pos.getY(i) + dt * .018;
      pos.setY(i, y > 4.6 ? -4.6 : y);
    }
    pos.needsUpdate = true;
  }
  const sweep = phoneGroup.getObjectByName('back-light-sweep');
  if (sweep && !reduceMotion) sweep.material.opacity = .1 + (Math.sin(time * .58) + 1) * .055;
  composer.render();
  frameCount++;
  if (!loaded && frameCount > 2) {
    loaded = true;
    loaderProgress.style.width = '100%';
    window.setTimeout(() => loader.classList.add('is-hidden'), 260);
  }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove('show'), 3200);
}

function selectColor(colorName) {
  if (!colorways[colorName]) return;
  currentColor = colorName;
  const color = colorways[colorName];
  phoneBodyMaterial.color.set(color.body);
  backGlassMaterial.color.set(color.back);
  frameMaterial.color.set(color.frame);
  if (starsMaterial && currentScene === 'colors') starsMaterial.color.set(color.particle);
  document.querySelectorAll('.color-option').forEach(button => {
    const active = button.dataset.color === colorName;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  document.querySelector('#current-color-name').textContent = color.name;
  applyScenePalette(currentScene);
  // Giữ ánh sáng ăn khớp với màu vỏ ngay cả khi đổi màu ở section khác.
  rimLeft.color.set(color.rimA);
  rimRight.color.set(color.rimB);
  if (starsMaterial) starsMaterial.color.set(color.particle);
  showToast(`Đã chọn màu ${color.name}. Kéo ngang để xoay điện thoại 3D.`);
}

function setupScroll() {
  const sections = gsap.utils.toArray('.story-section[data-scene]');
  sections.forEach((section, index) => {
    const sceneName = section.dataset.scene;
    ScrollTrigger.create({
      trigger: section,
      start: 'top 55%',
      end: 'bottom 45%',
      onEnter: () => setScene(sceneName),
      onEnterBack: () => setScene(sceneName),
    });
    const block = section.querySelector('.content-block');
    if (block && !reduceMotion && index > 0 && !section.classList.contains('specs-section')) {
      gsap.fromTo(block,
        { y: 32, opacity: .3, filter: 'blur(5px)' },
        { y: 0, opacity: 1, filter: 'blur(0px)', duration: .9, ease: 'power3.out', scrollTrigger: { trigger: section, start: 'top 68%', toggleActions: 'play none none reverse' } },
      );
    }
  });

  document.querySelectorAll('.spec-card').forEach((card, index) => {
    if (reduceMotion) return;
    gsap.fromTo(card, { opacity: 0, y: 22 }, { opacity: 1, y: 0, duration: .58, delay: (index % 4) * .045, ease: 'power2.out', scrollTrigger: { trigger: card, start: 'top 92%', toggleActions: 'play none none reverse' } });
  });

  document.querySelectorAll('[data-count]').forEach(el => {
    if (reduceMotion) return;
    const endValue = Number(el.dataset.count);
    const decimals = Number(el.dataset.decimals || 0);
    const counter = { value: 0 };
    ScrollTrigger.create({
      trigger: el,
      start: 'top 90%',
      once: true,
      onEnter: () => gsap.to(counter, {
        value: endValue,
        duration: 1.25,
        ease: 'power2.out',
        onUpdate: () => { el.textContent = counter.value.toFixed(decimals).replace('.', ','); },
      }),
    });
  });

  ScrollTrigger.create({ start: 'top -10', onUpdate: self => document.querySelector('#topbar').classList.toggle('scrolled', self.scroll() > 40) });
}

function setupControls() {
  document.querySelectorAll('.color-option').forEach(button => button.addEventListener('click', () => selectColor(button.dataset.color)));

  const menu = document.querySelector('#mobile-menu');
  const toggle = document.querySelector('#menu-toggle');
  const close = document.querySelector('#menu-close');
  const setMenu = open => {
    menu.classList.toggle('open', open);
    menu.setAttribute('aria-hidden', String(!open));
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Đóng menu' : 'Mở menu');
    document.body.style.overflow = open ? 'hidden' : '';
  };
  toggle.addEventListener('click', () => setMenu(!menu.classList.contains('open')));
  close.addEventListener('click', () => setMenu(false));
  menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => setMenu(false)));

  // Bộ điều khiển bàn phím xuất hiện khi người dùng chuyển focus đến nhóm này.
  document.querySelector('#rotate-left').addEventListener('click', () => { userYaw -= Math.PI / 4; lastInteraction = performance.now(); });
  document.querySelector('#rotate-right').addEventListener('click', () => { userYaw += Math.PI / 4; lastInteraction = performance.now(); });
  document.querySelector('#reset-view').addEventListener('click', () => {
    userYaw = 0;
    autoYaw = 0;
    targetYaw = sceneYaw[currentScene] ?? .2;
    if (phoneGroup) phoneGroup.scale.setScalar(initialModelScale);
    lastInteraction = performance.now();
    showToast('Đã đặt lại góc nhìn mô hình 3D.');
  });

  document.querySelector('#preorder-button').addEventListener('click', () => showToast('Đây là trang concept phi thương mại — chưa có chức năng đặt hàng.'));
  document.querySelector('#store-button').addEventListener('click', () => showToast('Đây là trang demo concept. Hãy kiểm tra nhà bán lẻ chính thức để tìm cửa hàng.'));
  document.querySelector('#privacy-link').addEventListener('click', event => {
    event.preventDefault();
    showToast('Demo không thu thập dữ liệu cá nhân và không dùng cookie theo dõi.');
  });

  const cursorDot = document.querySelector('#cursor-dot');
  const cursorRing = document.querySelector('#cursor-ring');
  if (window.matchMedia('(pointer: fine)').matches && !reduceMotion) {
    cursorDot.style.opacity = '1';
    cursorRing.style.opacity = '1';
    window.addEventListener('pointermove', event => {
      pointerX = event.clientX / window.innerWidth;
      pointerY = event.clientY / window.innerHeight;
      cursorDot.style.transform = `translate(${event.clientX}px, ${event.clientY}px)`;
      cursorRing.style.transform = `translate(${event.clientX}px, ${event.clientY}px)`;
    });
    document.querySelectorAll('a, button, .spec-card, .glass-spec').forEach(el => {
      el.addEventListener('pointerenter', () => cursorRing.classList.add('hovering'));
      el.addEventListener('pointerleave', () => cursorRing.classList.remove('hovering'));
    });
  }

  // Kéo ngang để xoay; vuốt dọc vẫn dành cho cuộn trang. Chụm hai ngón để zoom nhẹ.
  window.addEventListener('pointerdown', event => {
    lastInteraction = performance.now();
    activePointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (activePointers.size === 2) {
      const points = [...activePointers.values()];
      pinchStart = { distance: Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y), scale: phoneGroup.scale.x };
    }
  }, { passive: true });

  window.addEventListener('pointermove', event => {
    if (!activePointers.has(event.pointerId)) return;
    lastInteraction = performance.now();
    const previous = activePointers.get(event.pointerId);
    const next = { x: event.clientX, y: event.clientY };
    activePointers.set(event.pointerId, next);
    if (activePointers.size >= 2 && pinchStart && phoneGroup) {
      const points = [...activePointers.values()];
      const distance = Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y);
      const nextScale = THREE.MathUtils.clamp(pinchStart.scale * (distance / Math.max(1, pinchStart.distance)), initialModelScale * .82, initialModelScale * 1.16);
      phoneGroup.scale.setScalar(nextScale);
      return;
    }
    const dx = next.x - previous.x;
    const dy = next.y - previous.y;
    if (Math.abs(dx) > Math.abs(dy) * 1.18 && Math.abs(dx) > 1.5) {
      userYaw += dx * .009;
      if (Math.abs(userYaw) > Math.PI * 4) userYaw = THREE.MathUtils.euclideanModulo(userYaw + Math.PI, Math.PI * 2) - Math.PI;
    }
  }, { passive: true });
  const endPointer = event => {
    activePointers.delete(event.pointerId);
    if (activePointers.size < 2) pinchStart = null;
    lastInteraction = performance.now();
  };
  window.addEventListener('pointerup', endPointer, { passive: true });
  window.addEventListener('pointercancel', endPointer, { passive: true });

  // Ctrl + lăn chuột để zoom trên desktop, lăn bình thường vẫn cuộn trang.
  window.addEventListener('wheel', event => {
    if (!(event.ctrlKey || event.metaKey) || !phoneGroup) return;
    event.preventDefault();
    const nextScale = THREE.MathUtils.clamp(phoneGroup.scale.x - event.deltaY * .0005, initialModelScale * .82, initialModelScale * 1.16);
    phoneGroup.scale.setScalar(nextScale);
    lastInteraction = performance.now();
  }, { passive: false });
}

function boot() {
  try {
    initThree();
    setupScroll();
    setupControls();
    window.addEventListener('resize', () => {
      resizeThree();
      ScrollTrigger.refresh();
    });
    document.querySelectorAll('a[href^="#"]').forEach(link => {
      link.addEventListener('click', event => {
        const id = link.getAttribute('href');
        const target = id && document.querySelector(id);
        if (target) {
          event.preventDefault();
          target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
        }
      });
    });
    // Cho trình duyệt có thời gian dựng frame đầu trước khi đóng loading screen.
    window.setTimeout(() => {
      if (!loaded) {
        loaderProgress.style.width = '90%';
      }
    }, 120);
  } catch (error) {
    console.error('Không thể khởi tạo trải nghiệm 3D:', error);
    loader.classList.add('is-hidden');
    showToast('Thiết bị hoặc trình duyệt chưa khởi tạo được WebGL. Hãy thử Chrome mới nhất.');
  }
}

boot();
